const meeting = require("../model/meeting");

module.exports = function (io) {
    /*main router object which contain all function*/
    io.on('connection', socket => {
        socket.on('meetingId', socData => { 
            meeting.findOne({ meetingId: socData.mId })
            .lean()
            .exec(function (err, data) { 
                /** Flags
                 * 0=No data found
                 * 1=All is fine
                 * 2=Invalid password/Password not found
                 */
                let flag=0;
                if(data && data._id){
                    if(data.passReq==1){
                        if(socData.pass && socData.pass==data.password) flag=1;
                        else flag=2;
                    }
                    else flag=1;
                } 
                let retData={'id':'meetingReturn',data:flag,submit:socData.submit};
                socket.emit('message', retData); 
            });
        });
    });

    var router = {}; 
    router.meetingInfo = function (req, res) { 
        meeting.findOne({ meetingId: req.meetingId })
        .lean()
        .exec(function (err, data) {
            res.send(data);
        });
    };

    return router;
};