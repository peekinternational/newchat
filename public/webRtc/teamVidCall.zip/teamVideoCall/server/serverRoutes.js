/*
* author  => Peek International
* designBy => Peek International
*/
 
const serverController = require('./controller/serverController');  


module.exports = function (app, io) {

    /*create new object of chatController*/
    var serverCon = new serverController(io);  
    app.post('/meeting', serverCon.meetingInfo);
    
}