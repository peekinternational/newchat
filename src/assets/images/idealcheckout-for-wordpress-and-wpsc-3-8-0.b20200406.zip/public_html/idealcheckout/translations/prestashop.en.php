<?php

	$aTranslations = array();

	$aTranslations['Transaction status "{0}" recieved from Payment Service Provider (Cart ID: {1}).'] = 'Transaction status "{0}" recieved from Payment Service Provider (Cart ID: {1}).';

	return $aTranslations;

?>