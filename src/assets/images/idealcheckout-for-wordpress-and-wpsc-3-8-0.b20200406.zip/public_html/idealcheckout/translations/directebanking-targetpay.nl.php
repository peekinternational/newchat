<?php

	$aTranslations = array();

	$aTranslations['Your payment is recieved'] = 'Uw betaling is met succes ontvangen.';
	$aTranslations['Your payment was cancelled'] = 'Uw betaling is geannuleerd. Probeer opnieuw te betalen.';
	$aTranslations['Your payment is pending'] = 'Uw betaling is nog niet afgerond.';
	$aTranslations['Your payment is expired'] = 'Uw betaling is mislukt. Probeer opnieuw te betalen.';
	$aTranslations['Your payment has failed'] = 'Uw betaling is mislukt. Probeer opnieuw te betalen.';
	$aTranslations['Choose another payment method'] = 'Kies een andere betaalmethode';
	$aTranslations['Cancel payment'] = 'Ik kan nu niet betalen met deze betaalmethode';
	$aTranslations['Return to the website'] = 'Terug naar de website.';
	$aTranslations['Continue'] = 'Verder';

	return $aTranslations;

?>