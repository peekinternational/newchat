<?php

	$aTranslations = array();

	$aTranslations['Your payment is recieved'] = 'Your payment is recieved';
	$aTranslations['Your payment was cancelled'] = 'Your payment was cancelled, please try again';
	$aTranslations['Your payment is pending'] = 'Your payment is pending, please continue';
	$aTranslations['Your payment is expired'] = 'Your payment is expired, please try again';
	$aTranslations['Your payment has failed'] = 'Your payment has failed, please try again';
	$aTranslations['Choose another payment method'] = 'Choose another payment method';
	$aTranslations['Cancel payment'] = 'Cancel payment';
	$aTranslations['Return to the website'] = 'Return to the website';
	$aTranslations['Continue'] = 'Continue';

	return $aTranslations;

?>