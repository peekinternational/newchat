<?php

	$aTranslations = array();

	$aTranslations['Your payment is recieved'] = 'Ihre Zahlung ist eingegangen';
	$aTranslations['Your payment was cancelled'] = 'Ihre Zahlung wurde gel�scht / abgebrochen. Bitte versuchen Sie es erneut';
	$aTranslations['Your payment is pending'] = 'Ihre Zahlung steht noch aus. Bitte f�hren Sie die Zahlung durch.';
	$aTranslations['Your payment is expired'] = 'Ihre Zahulung ist verfallen. Bitte versuchen Sie es erneut.';
	$aTranslations['Your payment has failed'] = 'Ihre Zahlung ist fehlgeschlagen. Bitte versuchen Sie es erneut.';
	$aTranslations['Choose another payment method'] = 'Bitte W�hlen Sie eine andere Zahlungsmethode';
	$aTranslations['Cancel payment'] = 'Zahlung gel�scht';
	$aTranslations['Return to the website'] = 'Zur�ck zur Webseite';
	$aTranslations['Continue'] = 'Weitermachen';

	return $aTranslations;

?>