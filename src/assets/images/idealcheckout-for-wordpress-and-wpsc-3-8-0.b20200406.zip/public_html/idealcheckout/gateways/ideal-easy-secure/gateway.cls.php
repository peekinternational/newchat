<?php

	// Load gateway classes & libraries
	require_once(dirname(dirname(__FILE__)) . '/gateway.core.cls.5.php');
	require_once(dirname(__FILE__) . '/gateway.cls.5.php');
	require_once(dirname(__FILE__) . '/idealinternetkassa.cls.5.php');

?>