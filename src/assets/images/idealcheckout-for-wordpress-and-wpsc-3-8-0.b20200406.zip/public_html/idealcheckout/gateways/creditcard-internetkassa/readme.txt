Configuratie Rabo Internetkassa


TAB: Algemene transactieparameters
- "Standaard operatiecode" = "Verkoop"
- "Verwerking van individuele transacties" = "Online maar overschakelen naar offline wanneer het online systeem van de acquirer niet beschikbaar is."


TAB: Algemene beveiligingsparameters 
- "Stel de hash-reeks samen door de waarde samen te voegen van:" = "Elke parameter gevolgd door de passphrase."
- "Hash-algoritme:" = "SHA-1"
- "Karaktercodering:" = "ISO-8859-1"


TAB: Verificatie data en herkomst 
- "SHA-1-IN versleuteling" = Je eigen unieke beveiligingssleutel (moet ook in configuratie bestand worden overgenomen).


TAB: Transactiefeedback
- "Ik wil de feedbackparameters van de transacties op de redirectie-URL's ontvangen." = Aanvinken
- "Ik wil dat Online kassa Rabobank een kort redirectiebericht toont aan de klant voordat deze wordt teruggestuurd naar mijn website." = Uitvinken
- "SHA-1-OUT Versleuteling" = Je eigen unieke beveiligingssleutel (moet ook in configuratie bestand worden overgenomen).

