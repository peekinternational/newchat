<?php

	// HTTP Request over cUrl or fsock

	/*
	Possible configuration settings are:
	- curl
	- fsock
	*/

	// $aSettings['httprequest'] = 'curl';


?>