<?php

	// MySQL Server/Host
	$aSettings['host'] = 'localhost';

	// MySQL Username
	$aSettings['user'] = '';

	// MySQL Password
	$aSettings['pass'] = '';

	// MySQL Database name
	$aSettings['name'] = '';

	// MySQL Table Prefix
	$aSettings['prefix'] = '';

	// MySQL Library (MySQL or MySQLi)
	$aSettings['type'] = 'mysqli';

?>