<?php

	/*
		Let us help you to create a suitable configuration file for your iDEAL plugin.
		Go to: http://www.ideal-checkout.nl/
	*/

	$aSettings['TEST_MODE'] = true;

	// Basic gateway settings
	$aSettings['GATEWAY_NAME'] = 'iDEAL Simulator - Paysafecard';
	$aSettings['GATEWAY_WEBSITE'] = 'http://www.ideal-simulator.nl/';
	$aSettings['GATEWAY_METHOD'] = 'paysafecard-simulator';
	$aSettings['GATEWAY_VALIDATION'] = false;

?>