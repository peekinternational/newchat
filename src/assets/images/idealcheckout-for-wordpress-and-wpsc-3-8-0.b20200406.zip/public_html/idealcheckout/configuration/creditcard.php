<?php

	/*
		Let us help you to create a suitable configuration file for your iDEAL Checkout plug-in.
		Go to: http://www.ideal-checkout.nl/
	*/

	$aSettings['TEST_MODE'] = true;

	// Basic gateway settings
	$aSettings['GATEWAY_NAME'] = 'iDEAL Simulator - Creditcard';
	$aSettings['GATEWAY_WEBSITE'] = 'http://www.ideal-simulator.nl/';
	$aSettings['GATEWAY_METHOD'] = 'creditcard-simulator';
	$aSettings['GATEWAY_VALIDATION'] = false;



?>