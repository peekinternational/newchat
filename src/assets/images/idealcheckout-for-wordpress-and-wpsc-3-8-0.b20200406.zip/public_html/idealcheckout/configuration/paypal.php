<?php

	/*
		Let us help you to create a suitable configuration file for your iDEAL plugin.
		Go to: http://www.ideal-checkout.nl/
	*/

	$aSettings['PASSWORD_KEY'] = 'AE6DA27A-ACFC-363B-81F7-A852FEAD256A';
	$aSettings['TERMINAL_ID'] = 901;
	$aSettings['TEST_MODE'] = true;

	// Basic gateway settings
	$aSettings['GATEWAY_NAME'] = 'Cashflows/Paycheckout - Paypal';
	$aSettings['GATEWAY_WEBSITE'] = 'http://www.paycheckout.com/';
	$aSettings['GATEWAY_METHOD'] = 'paypal-cashflows';
	$aSettings['GATEWAY_VALIDATION'] = false;

?>