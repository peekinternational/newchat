<?php


	// Update order status when required
	function idealcheckout_update_order_status($aRecord, $sView)
	{
		idealcheckout_log('Updating status to "' . $aRecord['transaction_status'] . '" for order #' . $aRecord['order_id'], __FILE__, __LINE__);
		idealcheckout_log($aRecord, __FILE__, __LINE__);


		$sWpscAction = (strpos($aRecord['transaction_success_url'], '?') ? '&' : '?') . 'wpsc_action=gateway_notification&gateway=idealcheckout' . strtolower($aRecord['gateway_code']) . '&transaction_id=' . urlencode($aRecord['transaction_id']) . '&transaction_code=' . urlencode($aRecord['transaction_code']);


		// Find order state
		if(strcasecmp($aRecord['transaction_status'], 'SUCCESS') === 0)
		{
			if(!empty($aRecord['transaction_success_url']))
			{
				idealcheckout_log('Calling success URL: ' . $aRecord['transaction_success_url'] . $sWpscAction, __FILE__, __LINE__);
				idealcheckout_doHttpRequest($aRecord['transaction_success_url'] . $sWpscAction);
			}
		}
		elseif((strcasecmp($aRecord['transaction_status'], 'PENDING') === 0) || (strcasecmp($aRecord['transaction_status'], 'OPEN') === 0))
		{
			if(!empty($aRecord['transaction_pending_url']))
			{
				idealcheckout_log('Calling pending/open URL: ' . $aRecord['transaction_pending_url'] . $sWpscAction, __FILE__, __LINE__);
				idealcheckout_doHttpRequest($aRecord['transaction_pending_url'] . $sWpscAction);
			}
		}
		else
		{
			if(!empty($aRecord['transaction_failure_url']))
			{
				idealcheckout_log('Calling cancel/failure URL: ' . $aRecord['transaction_failure_url'] . $sWpscAction, __FILE__, __LINE__);
				idealcheckout_doHttpRequest($aRecord['transaction_failure_url'] . $sWpscAction);
			}
		}



		idealcheckout_log('Sending mail for order #' . $aRecord['order_id'], __FILE__, __LINE__);
		idealcheckout_sendMail($aRecord);
	}


?>